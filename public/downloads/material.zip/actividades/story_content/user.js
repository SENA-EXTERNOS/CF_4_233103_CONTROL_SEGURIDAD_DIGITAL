function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6gkRwR9mXBz":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

